﻿IPAexフォント
― はじめにお読みください ―

IPAexフォントは、JIS X 0213:2012に準拠したTrueTypeアウトラインベースのOpenTypeフォントです。

IPAexフォントの使用または利用に当たっては、添付の「IPAフォントライセンスv1.0」に定める条件に従ってください。
IPAexフォントを使用し、複製し、または頒布する行為、その他、「IPAフォントライセンスv1.0」に定める権利の利用を行った場合、受領者は「IPAフォントライセンスv1.0」に同意したものと見なします。


IPAexフォント2書体パック（IPAexゴシック、IPAex明朝）   IPAexfont00401.zip
|--はじめにお読みください   Readme_IPAexfont00401.txt
|--IPAフォントライセンスv1.0   IPA_Font_License_Agreement_v1.0.txt
|--IPAexゴシック(Ver.004.01)   ipaexg.ttf
|--IPAex明朝(Ver.004.01)  ipaexm.ttf


「IPAフォント」は、IPAの登録商標です。

=========================
IPAex Font 
-- Readme --

IPAex Fonts are JIS X 0213:2012 compliant OpenType fonts based on TrueType outlines.

In using IPAex fonts, please comply with the terms and conditions set out in "IPA Font License Agreement v1.0" included in this package.
Any use, reproduction or distribution of the IPA Font or any exercise of rights under "IPA Font License Agreement v1.0" by a Recipient constitutes the Recipient's acceptance of the License Agreement.


IPAex Fonts 2 fonts package （IPAex Gothic、IPAex Mincho）    IPAexfont00401.zip
|--Readme   Readme_IPAexfont00401.txt
|--IPA Font License Agreement v1.0   IPA_Font_License_Agreement_v1.0.txt
|--IPAexGothic(Ver.004.01)   ipaexg.ttf
|--IPAexMincho(Ver.004.01)   ipaexm.ttf


"IPA Font" is a registered trademark of IPA in Japan.
